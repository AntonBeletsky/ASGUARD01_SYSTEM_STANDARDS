#!/usr/bin/env python3
"""
combine_parts.py — Merge all MD parts into one final guide.

Reads parts/part_NN_*.md in order, builds a global TOC,
strips internal part headers, and writes one clean final_guide.md.

Usage:
    python combine_parts.py
    python combine_parts.py ./parts/
    python combine_parts.py ./parts/ ./output/final_guide.md
    python combine_parts.py --skip-empty        # exclude unfilled sections
"""

import re
import sys
import argparse
from pathlib import Path
from datetime import datetime


TITLE = "Ultimate Software Engineering Knowledge Architecture"


# ── Helpers ────────────────────────────────────────────────────────────────

def parse_meta(content: str) -> dict | None:
    m = re.search(
        r"<!-- PART_META\npart: (\d+)\nvolume_id: (\d+)\ntitle: (.+?)\ngenerated: (.+?)\n-->",
        content, re.DOTALL
    )
    return {
        "part":      int(m.group(1)),
        "volume_id": int(m.group(2)),
        "title":     m.group(3).strip(),
        "generated": m.group(4).strip(),
    } if m else None


def slugify(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"\s+", "-", text)
    return re.sub(r"-+", "-", text).strip("-")


def count_sections(content: str) -> tuple[int, int]:
    total  = len(re.findall(r"<!-- SECTION_START", content))
    filled = len(re.findall(r"status: filled", content))
    return filled, total


def strip_part_header(content: str) -> str:
    """Remove PART_META comment block from top of part."""
    return re.sub(
        r"^<!-- PART_META\n.*?-->\n\n?",
        "",
        content,
        flags=re.DOTALL
    )


def remove_empty_sections(content: str) -> str:
    """Remove sections that still have no content (status: empty)."""
    # Remove from ### heading through the closing CONTENT_END marker
    return re.sub(
        r"### [^\n]+\n\n<!-- SECTION_START\n.*?status: empty\n-->\n\n"
        r"<!-- CONTENT_START:[^\n]+ -->\n\n<!-- CONTENT_END:[^\n]+ -->\n\n---\n",
        "",
        content,
        flags=re.DOTALL
    )


# ── TOC builders ───────────────────────────────────────────────────────────

def global_toc(parsed: list[dict]) -> str:
    lines = ["## Table of Contents", ""]
    for p in parsed:
        vol_id = p["meta"]["volume_id"]
        title  = p["meta"]["title"]
        anchor = slugify(f"vol {vol_id} {title}")
        filled, total = p["filled"], p["total"]
        bar_n  = int(filled / total * 10) if total else 0
        bar    = "█" * bar_n + "░" * (10 - bar_n)
        pct    = f"{int(filled / total * 100)}%" if total else "0%"
        lines.append(f"- [Vol {vol_id}. {title}](#{anchor})  `{filled}/{total}` [{bar}] {pct}")
    return "\n".join(lines)


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Combine MD parts into final guide")
    parser.add_argument("parts_dir",   nargs="?", default="parts",               help="Parts directory")
    parser.add_argument("output_file", nargs="?", default="output/final_guide.md", help="Output file")
    parser.add_argument("--skip-empty", action="store_true", help="Exclude unfilled sections from output")
    args = parser.parse_args()

    parts_dir   = Path(args.parts_dir)
    output_file = Path(args.output_file)

    if not parts_dir.exists():
        print(f"[ERROR] Parts directory not found: {parts_dir}")
        sys.exit(1)

    # ── Load and sort parts ───────────────────────────────────────────────
    part_files = sorted(parts_dir.glob("part_*.md"))
    if not part_files:
        print(f"[ERROR] No part_*.md files in {parts_dir}")
        sys.exit(1)

    parsed = []
    for pf in part_files:
        text = pf.read_text(encoding="utf-8")
        meta = parse_meta(text)
        if not meta:
            print(f"[WARN] No metadata in {pf.name}, skipping")
            continue
        filled, total = count_sections(text)
        parsed.append({"path": pf, "meta": meta, "text": text, "filled": filled, "total": total})

    parsed.sort(key=lambda x: x["meta"]["part"])

    total_filled   = sum(p["filled"] for p in parsed)
    total_sections = sum(p["total"]  for p in parsed)
    pct_overall    = int(total_filled / total_sections * 100) if total_sections else 0

    # ── Build output ──────────────────────────────────────────────────────
    output_file.parent.mkdir(parents=True, exist_ok=True)
    out = []

    # Global header
    out += [
        f"# {TITLE}",
        "",
        f"> **Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}  ",
        f"> **Volumes:** {len(parsed)}  ",
        f"> **Progress:** {total_filled}/{total_sections} sections filled ({pct_overall}%)",
        "",
        "---",
        "",
        global_toc(parsed),
        "",
        "---",
        "",
    ]

    # Append parts
    for p in parsed:
        text = strip_part_header(p["text"])
        if args.skip_empty:
            text = remove_empty_sections(text)
        out.append(text)
        out.append("")

    final = "\n".join(out)
    output_file.write_text(final, encoding="utf-8")

    size_kb = output_file.stat().st_size / 1024
    print(f"[DONE] {output_file}  ({size_kb:.1f} KB)")
    print(f"[INFO] {len(parsed)} volumes  |  {total_filled}/{total_sections} sections filled ({pct_overall}%)")


if __name__ == "__main__":
    main()
