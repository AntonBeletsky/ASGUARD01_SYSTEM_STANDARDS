#!/usr/bin/env python3
"""
generate_parts.py — Create empty MD part files from guide JSON.

Each section gets a content block with markers the filler/AI can target.

Usage:
    python generate_parts.py
    python generate_parts.py guide.json
    python generate_parts.py guide.json ./parts/
"""

import json
import re
import sys
from pathlib import Path
from datetime import datetime


# ── Helpers ────────────────────────────────────────────────────────────────

def slugify(text: str) -> str:
    text = text.lower()
    text = re.sub(r"[^\w\s-]", "", text)
    text = re.sub(r"[\s_]+", "-", text)
    return re.sub(r"-+", "-", text).strip("-")


def md_anchor(text: str) -> str:
    """GitHub-compatible anchor: remove non-alphanum, spaces → hyphens."""
    text = text.lower()
    text = re.sub(r"[^a-z0-9\s-]", "", text)
    text = re.sub(r"\s+", "-", text)
    return re.sub(r"-+", "-", text).strip("-")


# ── Section content block template ────────────────────────────────────────

def section_block(sec_id: str, sec_title: str, ch_title: str, vol_title: str) -> str:
    """
    One section = heading + machine-readable marker block.
    The CONTENT_START / CONTENT_END delimiters are how fill_sections.py
    and combine_parts.py locate and replace content.
    """
    return (
        f"### {sec_id} {sec_title}\n"
        f"\n"
        f"<!-- SECTION_START\n"
        f"id: {sec_id}\n"
        f"title: {sec_title}\n"
        f"chapter: {ch_title}\n"
        f"volume: {vol_title}\n"
        f"status: empty\n"
        f"-->\n"
        f"\n"
        f"<!-- CONTENT_START:{sec_id} -->\n"
        f"\n"
        f"<!-- CONTENT_END:{sec_id} -->\n"
        f"\n"
        f"---\n"
    )


# ── Part file builder ──────────────────────────────────────────────────────

def build_part(volume: dict) -> str:
    vol_id    = volume["id"]
    vol_title = volume["title"]
    chapters  = volume["chapters"]

    lines = []

    # Machine-readable header
    lines += [
        f"<!-- PART_META",
        f"part: {vol_id:02d}",
        f"volume_id: {vol_id}",
        f"title: {vol_title}",
        f"generated: {datetime.now().strftime('%Y-%m-%d')}",
        f"-->",
        "",
    ]

    # Volume heading
    lines += [f"# Vol {vol_id}. {vol_title}", ""]

    # Per-volume TOC
    lines += ["## Contents", ""]
    for ch in chapters:
        ch_id, ch_title = ch["id"], ch["title"]
        lines.append(f"- [{ch_id} {ch_title}](#{md_anchor(ch_id + ' ' + ch_title)})")
        for sec in ch["sections"]:
            sec_id, sec_title = sec["id"], sec["title"]
            lines.append(f"  - [{sec_id} {sec_title}](#{md_anchor(sec_id + ' ' + sec_title)})")
    lines += ["", "---", ""]

    # Content sections
    for ch in chapters:
        ch_id, ch_title = ch["id"], ch["title"]
        lines += [f"## {ch_id} {ch_title}", ""]
        for sec in ch["sections"]:
            lines.append(
                section_block(sec["id"], sec["title"], ch_title, vol_title)
            )

    return "\n".join(lines)


# ── Main ───────────────────────────────────────────────────────────────────

def main():
    json_path  = Path(sys.argv[1]) if len(sys.argv) > 1 else Path("guide.json")
    output_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path("parts")

    if not json_path.exists():
        print(f"[ERROR] JSON not found: {json_path}")
        sys.exit(1)

    output_dir.mkdir(parents=True, exist_ok=True)
    data    = json.loads(json_path.read_text(encoding="utf-8"))
    volumes = data["guide"]["volumes"]

    print(f"[INFO] {len(volumes)} volumes → writing to {output_dir}/\n")

    for vol in volumes:
        slug     = slugify(vol["title"])
        filename = f"part_{vol['id']:02d}_{slug}.md"
        filepath = output_dir / filename

        # Don't overwrite already-filled parts
        if filepath.exists():
            print(f"  SKIP {filename}  (already exists)")
            continue

        content   = build_part(vol)
        filepath.write_text(content, encoding="utf-8")

        sec_count = sum(len(ch["sections"]) for ch in vol["chapters"])
        print(f"  ✓  {filename}  ({len(vol['chapters'])} ch, {sec_count} sec)")

    print(f"\n[DONE] Parts in {output_dir}/")


if __name__ == "__main__":
    main()
