#!/usr/bin/env python3
"""
status.py — Show fill progress across all part files.

Usage:
    python status.py
    python status.py ./parts/
    python status.py --list-empty          # print all empty section IDs
    python status.py --list-empty --vol 3  # empty sections in volume 3
"""

import re
import sys
import argparse
from pathlib import Path


def parse_meta(content: str) -> dict | None:
    m = re.search(
        r"<!-- PART_META\npart: (\d+)\nvolume_id: (\d+)\ntitle: (.+?)\n",
        content, re.DOTALL
    )
    return {"part": int(m.group(1)), "volume_id": int(m.group(2)), "title": m.group(3).strip()} if m else None


def get_sections(content: str) -> list[dict]:
    pattern = re.compile(
        r"<!-- SECTION_START\nid: (.+?)\ntitle: (.+?)\nchapter: (.+?)\nvolume: (.+?)\nstatus: (.+?)\n-->",
        re.DOTALL
    )
    return [
        {"id": m.group(1).strip(), "title": m.group(2).strip(),
         "chapter": m.group(3).strip(), "status": m.group(5).strip()}
        for m in pattern.finditer(content)
    ]


def progress_bar(filled: int, total: int, width: int = 20) -> str:
    n   = int(filled / total * width) if total else 0
    pct = int(filled / total * 100)   if total else 0
    return f"[{'█' * n}{'░' * (width - n)}] {filled:>3}/{total:<3} {pct:>3}%"


def main():
    parser = argparse.ArgumentParser(description="Show fill progress")
    parser.add_argument("parts_dir",    nargs="?", default="parts")
    parser.add_argument("--list-empty", action="store_true", help="Print all empty section IDs")
    parser.add_argument("--vol",        type=int,            help="Filter to one volume")
    args = parser.parse_args()

    parts_dir = Path(args.parts_dir)
    files     = sorted(parts_dir.glob("part_*.md"))

    if not files:
        print(f"[ERROR] No parts found in {parts_dir}")
        sys.exit(1)

    rows          = []
    total_filled  = 0
    total_all     = 0
    empty_ids     = []

    for f in files:
        content  = f.read_text(encoding="utf-8")
        meta     = parse_meta(content)
        if not meta:
            continue
        if args.vol and meta["volume_id"] != args.vol:
            continue

        sections = get_sections(content)
        filled   = sum(1 for s in sections if s["status"] == "filled")
        total    = len(sections)

        rows.append({"meta": meta, "filled": filled, "total": total})
        total_filled += filled
        total_all    += total

        if args.list_empty:
            for s in sections:
                if s["status"] == "empty":
                    empty_ids.append((meta["volume_id"], s["id"], s["title"], s["chapter"]))

    # ── Print table ───────────────────────────────────────────────────────
    col_title = 36
    print()
    print(f"  {'Vol':<4}  {'Title':<{col_title}}  Progress")
    print(f"  {'─'*4}  {'─'*col_title}  {'─'*32}")

    for r in rows:
        vol_id = r["meta"]["volume_id"]
        title  = r["meta"]["title"][:col_title]
        bar    = progress_bar(r["filled"], r["total"])
        flag   = "✓" if r["filled"] == r["total"] else ("·" if r["filled"] == 0 else "▓")
        print(f"  {flag} {vol_id:<3}  {title:<{col_title}}  {bar}")

    print(f"  {'─'*4}  {'─'*col_title}  {'─'*32}")
    print(f"  {'TOTAL':<{col_title + 6}}  {progress_bar(total_filled, total_all)}")
    print()

    # ── List empty sections ───────────────────────────────────────────────
    if args.list_empty and empty_ids:
        print(f"  Empty sections ({len(empty_ids)}):\n")
        cur_vol = None
        for vol_id, sec_id, title, chapter in empty_ids:
            if vol_id != cur_vol:
                print(f"  Vol {vol_id}")
                cur_vol = vol_id
            print(f"    {sec_id:<12}  {chapter} → {title}")
        print()


if __name__ == "__main__":
    main()
