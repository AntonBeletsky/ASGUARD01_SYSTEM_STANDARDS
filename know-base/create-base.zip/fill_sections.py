#!/usr/bin/env python3
"""
fill_sections.py — Fill empty sections in MD parts using Claude API.

For each section with status:empty it calls the Anthropic API and writes
the response between CONTENT_START and CONTENT_END markers.

Usage:
    python fill_sections.py                        # fills all empty parts
    python fill_sections.py parts/part_01_*.md     # fill specific file(s)
    python fill_sections.py --dry-run              # show what would be filled
    python fill_sections.py --volume 1             # fill only volume 1
    python fill_sections.py --section 1.1.1        # fill one specific section

Env vars:
    ANTHROPIC_API_KEY   your key (required)
    FILL_LANG           php,js  (default: php,js)
"""

import os
import re
import sys
import json
import time
import argparse
from pathlib import Path
import urllib.request
import urllib.error


# ── Config ─────────────────────────────────────────────────────────────────

API_URL   = "https://api.anthropic.com/v1/messages"
MODEL     = "claude-opus-4-5"
MAX_TOKENS = 2000
LANGUAGES = os.getenv("FILL_LANG", "php,js")

SYSTEM_PROMPT = """You are a senior software engineer writing a professional
technical reference guide. Write concise, accurate, practical content for
the section given. Structure each section as:

**Concept** — one sentence definition.

**Why it matters** — 2-3 sentences on purpose and context.

**Core rules / key points** — 3-5 bullet points (no sub-bullets).

**Example** — one realistic code example in PHP, then one in JS.
Keep examples short (5-15 lines), focused on the concept only.
Use ```php and ```js fences.

**Common mistakes** — 2-3 bullet points.

No headers beyond what is specified. No verbose introductions.
Total length: 200-350 words. Be direct and practical."""


# ── Marker helpers ─────────────────────────────────────────────────────────

SECTION_META_RE = re.compile(
    r"<!-- SECTION_START\nid: (.+?)\ntitle: (.+?)\nchapter: (.+?)\nvolume: (.+?)\nstatus: (.+?)\n-->",
    re.DOTALL
)
CONTENT_BLOCK_RE = re.compile(
    r"(<!-- CONTENT_START:({sec_id}) -->)\n(.*?)(<!-- CONTENT_END:\2 -->)",
    re.DOTALL
)


def find_empty_sections(text: str) -> list[dict]:
    """Return list of empty section metadata dicts."""
    results = []
    for m in SECTION_META_RE.finditer(text):
        if m.group(5).strip() == "empty":
            results.append({
                "id":      m.group(1).strip(),
                "title":   m.group(2).strip(),
                "chapter": m.group(3).strip(),
                "volume":  m.group(4).strip(),
            })
    return results


def replace_content(text: str, sec_id: str, new_content: str) -> str:
    """Replace content between markers and update status to filled."""
    # Update SECTION_START status
    text = re.sub(
        rf"(<!-- SECTION_START\nid: {re.escape(sec_id)}\ntitle: .+?\nchapter: .+?\nvolume: .+?\nstatus: )empty(\n-->)",
        rf"\1filled\2",
        text,
        flags=re.DOTALL
    )
    # Replace content block
    pattern = (
        rf"(<!-- CONTENT_START:{re.escape(sec_id)} -->)\n"
        rf"(.*?)"
        rf"(<!-- CONTENT_END:{re.escape(sec_id)} -->)"
    )
    replacement = rf"\1\n\n{new_content}\n\n\3"
    text = re.sub(pattern, replacement, text, flags=re.DOTALL)
    return text


# ── API call ────────────────────────────────────────────────────────────────

def build_prompt(sec: dict) -> str:
    return (
        f"Write the section for:\n\n"
        f"Volume: {sec['volume']}\n"
        f"Chapter: {sec['chapter']}\n"
        f"Section: {sec['id']} — {sec['title']}\n\n"
        f"Languages for code examples: {LANGUAGES}\n"
        f"Follow the format specified in your instructions exactly."
    )


def call_api(prompt: str, api_key: str) -> str:
    payload = json.dumps({
        "model": MODEL,
        "max_tokens": MAX_TOKENS,
        "system": SYSTEM_PROMPT,
        "messages": [{"role": "user", "content": prompt}]
    }).encode("utf-8")

    req = urllib.request.Request(
        API_URL,
        data=payload,
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
        },
        method="POST"
    )

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read())
            return data["content"][0]["text"].strip()
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        raise RuntimeError(f"API error {e.code}: {body}")


# ── File processor ─────────────────────────────────────────────────────────

def process_file(filepath: Path, api_key: str, dry_run: bool,
                 target_section: str | None = None,
                 delay: float = 1.0) -> tuple[int, int]:
    """Fill empty sections in one file. Returns (filled, skipped)."""
    text     = filepath.read_text(encoding="utf-8")
    sections = find_empty_sections(text)

    if target_section:
        sections = [s for s in sections if s["id"] == target_section]

    if not sections:
        return 0, 0

    filled = 0
    print(f"\n  {filepath.name}  ({len(sections)} empty sections)")

    for sec in sections:
        label = f"    [{sec['id']}] {sec['title']}"
        if dry_run:
            print(f"{label}  → DRY RUN")
            continue

        print(f"{label}  → ", end="", flush=True)
        try:
            content = call_api(build_prompt(sec), api_key)
            text    = replace_content(text, sec["id"], content)
            filepath.write_text(text, encoding="utf-8")
            filled += 1
            print("✓")
            time.sleep(delay)  # rate-limit safety
        except Exception as e:
            print(f"✗ ERROR: {e}")

    return filled, len(sections) - filled


# ── Main ────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="Fill empty MD sections via Claude API")
    parser.add_argument("files",         nargs="*",       help="Part files to process (default: parts/*.md)")
    parser.add_argument("--parts-dir",   default="parts", help="Parts directory")
    parser.add_argument("--dry-run",     action="store_true")
    parser.add_argument("--volume",      type=int,        help="Fill only this volume id")
    parser.add_argument("--section",                      help="Fill only this section id, e.g. 1.1.1")
    parser.add_argument("--delay",       type=float, default=1.0, help="Seconds between API calls")
    args = parser.parse_args()

    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key and not args.dry_run:
        print("[ERROR] Set ANTHROPIC_API_KEY env var")
        sys.exit(1)

    # Resolve files
    if args.files:
        files = [Path(f) for f in args.files]
    else:
        parts_dir = Path(args.parts_dir)
        files = sorted(parts_dir.glob("part_*.md"))
        if args.volume:
            files = [f for f in files if f.name.startswith(f"part_{args.volume:02d}_")]

    if not files:
        print("[ERROR] No part files found.")
        sys.exit(1)

    print(f"[INFO] Processing {len(files)} file(s)  |  dry_run={args.dry_run}")

    total_filled = total_skipped = 0
    for f in files:
        if not f.exists():
            print(f"[WARN] Not found: {f}")
            continue
        filled, skipped = process_file(
            f, api_key or "", args.dry_run,
            target_section=args.section,
            delay=args.delay
        )
        total_filled  += filled
        total_skipped += skipped

    print(f"\n[DONE] Filled: {total_filled}  |  Errors/skipped: {total_skipped}")


if __name__ == "__main__":
    main()
