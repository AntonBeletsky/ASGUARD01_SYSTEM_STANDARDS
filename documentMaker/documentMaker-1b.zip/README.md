# doc_generator.py

A documentation generator for frontend projects (HTML / CSS / JS).

The script walks a project directory, parses every HTML/CSS/JS file with
awareness of that language's own syntax, and finds the relationships
between files — both structural (`<link>`, `<script src>`, `@import`,
`import`/`require`) and semantic (which JS/CSS reaches into which
`#id`/`.class` in the HTML) — then packages all of it into **a single
self-contained HTML file**: the documentation's own CSS and JS are inlined,
so reading it needs no internet connection and doesn't require building or
installing the project it documents.

Dependencies: the Python standard library only, Python 3.9+. Nothing to
install.

## Quick start

```bash
python3 doc_generator.py /path/to/project -o documentation.html
```

Open `documentation.html` in a browser.

## CLI options

| Flag | Default | Description |
|---|---|---|
| `project_dir` | — | path to the root of the frontend project (required) |
| `-o, --output` | `documentation.html` | path to the output file |
| `--title` | the project folder's name | documentation title |
| `--ignore` | — | extra glob pattern to exclude files (repeatable) |
| `--no-default-ignore` | off | don't exclude node_modules/.git/dist/vendor/etc. |

## What ends up in the documentation

- **Directory map** — the full project tree in the sidebar (collapsible
  folders built on plain `<details>/<summary>`, no JS involved).
- **Project overview** — file counts by type, lines of code, size, the
  project's color palette (collected from color values in the CSS),
  responsive breakpoints, detected external libraries/CDNs.
- **Dependency map** — an SVG graph: HTML/CSS/JS files as nodes in three
  columns, with solid lines for structural references and dashed lines for
  semantic (DOM) ones.
- **A card for every file**: path, size, LOC, what it depends on and where
  it's used (structural and semantic links shown separately), plus "Code"
  (syntax highlighting) and "Structure" tabs:
  - **HTML** — title/lang/description, the h1–h6 heading outline, landmark
    tags, forms and their fields, images (checked for `alt`), every
    `id`/`class` on the page, comments.
  - **CSS** — custom properties (variables) with a color swatch preview,
    media breakpoints, `@font-face`/`@keyframes`/`@supports`, and a living
    list of rules — "selector → the author's comment → declarations" (in
    the spirit of KSS/a living style guide — see "What's worth studying
    further" below).
  - **JS** — imports/exports (ES modules and CommonJS), functions and
    classes together with their JSDoc (description, `@param`, `@returns`,
    `@example`), DOM access (`querySelector`, `getElementById`, …), event
    listeners, network calls (`fetch`/XHR/axios), TODO/FIXME.
- **"Cartographer's notes"** — automatic warnings: id/class declared in
  HTML but never used anywhere; CSS selectors with no match in HTML; broken
  internal links; images without `alt`.

## Architecture (see the full breakdown in the chat)

```
scan_project()  → directory tree + lists of html/css/js paths
analyze_html()  → HtmlInfo   (html.parser.HTMLParser, standard library)
analyze_css()   → CssInfo    (a hand-written single-pass tokenizer)
analyze_js()    → JsInfo     (comment/string masking + regex)
build_edges()   → list of Edge (structural and DOM links between files)
analyze_project_stats() → aggregated project statistics
render_document() → assembles one HTML file via DOCUMENT_TEMPLATE (placeholders __X__)
```

Every file is parsed exactly once into a `*Info` object; those objects are
the single source of truth for displaying code, building the link graph,
and computing statistics alike. The HTML document itself is a string
template with placeholders (`__TITLE__`, `__SIDEBAR_TREE__`,
`__FILE_SECTIONS__`, etc.) filled in once inside `render_document()`; this
is deliberately not Jinja2 and not f-strings/`.format()` (their `{}` would
collide with literal CSS/JS) — just plain `.replace()` calls, so the script
stays a single file with no dependencies.

## Known limitations (worth understanding)

This is **static, heuristic analysis**, not a full compiler:

- **JS is parsed with regular expressions**, not a real AST (Acorn/Babel/the
  TypeScript compiler API aren't available here without Node.js). Regular
  `'...'`/`"..."` string literals are deliberately NOT masked (import paths
  and selectors live inside them), so code inside a string that happens to
  look like a function declaration could in theory produce a false
  positive. Telling a regex literal `/.../` apart from a division operator
  uses a simplified rule, not the full JS grammar. `querySelector(aVariable)`
  is not resolved — only literal strings are.
- **Minified files** (detected heuristically via very long lines) aren't
  parsed in detail — only their size/badge is shown, so the documentation
  doesn't drown in unreadable output.
- **The CSS parser** is a hand-written tokenizer based on brace-balancing,
  not the formal CSS grammar; native CSS nesting (`&`) and exotic selectors
  (e.g. commas inside `:is(a, b)`) are handled approximately.
- **DOM links** are only found where the selector is a literal string in
  JS/CSS; elements created entirely dynamically (e.g. via a templating
  engine working on strings) won't show up in the dependency map.
- The script **never executes the project's code** — a plus for safety (you
  can safely point it at an untrusted third-party project) and a minus for
  accuracy (nothing that only appears at runtime is visible).

If you need fully accurate information about JS structure, the next
logical step is wiring in a real parser (see the analysis in the chat,
"What's worth studying further").
