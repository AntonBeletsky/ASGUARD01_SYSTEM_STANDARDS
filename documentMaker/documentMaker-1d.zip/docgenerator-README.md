# docgenerator

Documentation tooling for frontend (HTML/CSS/JS) projects. This bundle
contains **two related but independently-usable projects** built around
the same core idea: scan a frontend project, understand how its
HTML/CSS/JS files actually connect (not just by file reference, but by
which CSS/JS touches which HTML elements), and turn that into a single
self-contained, offline-readable HTML reference document.

```
docgenerator/
├── README.md                  ← you are here
├── doc-generator-cli/          Project 1 — run it yourself, by hand
└── docgenerator.skill/         Project 2 — an LLM agent runs it for you
```

## Which one do you want?

| | `doc-generator-cli/` | `docgenerator.skill/` |
|---|---|---|
| **What it is** | A plain Python script | A Claude Agent Skill |
| **Who runs it** | You, from a terminal | An LLM agent (Claude Code, Cowork, an API-based agent, …), autonomously |
| **How you use it** | `python3 doc_generator.py ...` | Ask the agent to document/explain a frontend project in plain language |
| **Requires** | Python 3.9+, nothing else | An agent harness that loads Agent Skills |
| **Start here** | [`doc-generator-cli/README.md`](doc-generator-cli/README.md) | [`docgenerator.skill/SKILL.md`](docgenerator.skill/SKILL.md) |

If you just want to generate a doc file right now, use the CLI directly —
it's the faster path with no agent involved. If you want a Claude-based
tool that decides on its own when to reach for this capability while
helping someone with a broader task (and can also just *answer questions*
about a codebase's structure instead of always producing a file), install
the skill.

## How they relate

`docgenerator.skill/` bundles its own copy of the exact same
`doc_generator.py` — same file, same logic, same output. Nothing about the
generator's behavior differs between the two; only *who* invokes it and
*how the result gets used* differs. The skill adds a layer on top: it
tells an LLM agent when this tool is the right one to reach for, how to
run it, how to talk about the (heuristic, not-infallible) results
honestly, and how to use it as an analysis tool for conversational
questions rather than only as a file generator. See
`docgenerator.skill/references/` for that layer in full.

The two copies of `doc_generator.py` are kept manually in sync — see
"Keeping this in sync" in `docgenerator.skill/README.md` if you're
maintaining both.

## What the generator actually produces

Regardless of which project runs it: a directory tree map, a project-wide
overview (stats, color palette, external libraries, automatically-flagged
issues), an SVG dependency graph distinguishing structural links
(`<link>`, `<script src>`, `import`) from semantic DOM links (which JS/CSS
actually reaches into which HTML elements), and a card per file with
syntax-highlighted source plus a parsed structure breakdown (headings/forms
for HTML, custom properties/rules for CSS, functions/classes/JSDoc for
JS). All of it in one `.html` file, openable straight from disk, no
internet connection or build step required to read it.

Full design rationale, the research this was based on (MDN, Microsoft
Learn, marketplace-template documentation conventions, JSDoc/Storybook/KSS),
and the reasoning behind the visual design are part of the conversation
this bundle was built in — the `references/` folder inside the skill
project captures the parts of that reasoning an LLM agent actually needs
at runtime; `doc-generator-cli/README.md` captures the parts a human
running the script needs.

## Status

Both projects are complete, working code — not placeholders.

- **`doc-generator-cli/`** — run end-to-end, output visually verified
  across several rounds (including a full English localization pass).
- **`docgenerator.skill/`** — passes the real `skill-creator` validator,
  packaged into an actual distributable `docgenerator.skill.skill` archive
  (validation caught and fixed two real spec violations along the way —
  see `docgenerator.skill/README.md` for specifics). Its `evals.json` test
  prompts have been traced manually against the shipped instructions
  rather than run through the automated subagent-based eval loop, which
  needs API access this environment doesn't have — see
  `docgenerator.skill/evals/manual-trace-results.md` for that trace,
  including one open question it flags rather than papers over.
