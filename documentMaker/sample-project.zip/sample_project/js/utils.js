// Небольшие переиспользуемые хелперы без побочных эффектов.

/**
 * Проверяет строку на формат email.
 * @param {string} value - введённое значение
 * @returns {boolean} true, если строка похожа на email
 */
export function isValidEmail(value) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);
}

/**
 * Ограничивает вызов функции не чаще, чем раз в `wait` мс.
 * @param {Function} fn - исходная функция
 * @param {number} wait - задержка в миллисекундах
 * @returns {Function} обёрнутая функция
 * @example
 * const onScroll = debounce(() => console.log('scroll'), 200);
 */
export function debounce(fn, wait) {
  let timer = null;
  return function debounced(...args) {
    clearTimeout(timer);
    timer = setTimeout(() => fn.apply(this, args), wait);
  };
}

/**
 * Простое хранилище состояния темы в памяти вкладки.
 */
export class ThemeStore {
  /**
   * @param {string} initial - начальная тема ('light' | 'dark')
   */
  constructor(initial = "light") {
    this.theme = initial;
  }

  /** Переключает тему на противоположную. */
  toggle() {
    this.theme = this.theme === "light" ? "dark" : "light";
    return this.theme;
  }
}
