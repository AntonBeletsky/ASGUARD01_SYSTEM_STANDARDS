import { isValidEmail, debounce, ThemeStore } from "./utils.js";

// TODO: подключить реальную отправку формы на бэкенд

const themeStore = new ThemeStore("light");

/**
 * Инициализирует переключатель темы.
 */
function initThemeToggle() {
  const button = document.getElementById("theme-toggle");
  if (!button) return;
  button.addEventListener("click", () => {
    const next = themeStore.toggle();
    document.documentElement.dataset.theme = next;
  });
}

/**
 * Инициализирует форму захвата лида: валидацию и отправку.
 * @param {string} formSelector - CSS-селектор формы
 */
function initLeadForm(formSelector) {
  const form = document.querySelector(formSelector);
  if (!form) return;

  const emailInput = document.getElementById("lead-email");

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!isValidEmail(emailInput.value)) {
      emailInput.classList.add("input--error");
      return;
    }
    console.log("Отправка каталога на", emailInput.value);
  });
}

/**
 * Подсвечивает активный пункт навигации при прокрутке.
 */
function initScrollSpy() {
  const sections = document.querySelectorAll(".features, .pricing");
  const onScroll = debounce(() => {
    sections.forEach((section) => {
      const rect = section.getBoundingClientRect();
      if (rect.top < 120 && rect.bottom > 120) {
        section.classList.add("is-active");
      } else {
        section.classList.remove("is-active");
      }
    });
  }, 100);
  window.addEventListener("scroll", onScroll);
}

document.addEventListener("DOMContentLoaded", () => {
  initThemeToggle();
  initLeadForm("#lead-form");
  initScrollSpy();
});
