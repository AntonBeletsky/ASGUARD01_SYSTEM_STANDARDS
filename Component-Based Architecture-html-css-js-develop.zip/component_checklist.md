# Чеклист разработки HTML/CSS/JS компонентов

## 📋 ПЕРЕД НАЧАЛОМ РАЗРАБОТКИ

### Планирование
- [ ] **Определена цель компонента** - что это делает, зачем нужно
- [ ] **Определены состояния** - все возможные состояния (normal, hover, active, disabled, error, loading)
- [ ] **Определены модификаторы** - все вариации компонента (размеры, цвета, типы)
- [ ] **Определены события** - что компонент должен испускать/слушать
- [ ] **Выбрана архитектура** - vanilla JS, Web Components, React, Vue и т.д.
- [ ] **Продумана доступность** - ARIA, семантический HTML, фокус

### Структура папок
```
components/
├── MyComponent/
│   ├── MyComponent.html      (разметка)
│   ├── MyComponent.css       (стили)
│   ├── MyComponent.js        (логика)
│   ├── MyComponent.test.js   (тесты)
│   ├── MyComponent.config.js (конфигурация)
│   └── README.md             (документация)
```

---

## 🏗️ РАЗРАБОТКА HTML ЧАСТИ

### Семантика
- [ ] **Используется правильный HTML тег** - `<button>` для кнопок, `<input>` для ввода
- [ ] **Структура логична** - контент вложен логично
- [ ] **Нет излишних div** - только необходимые контейнеры
- [ ] **Используются семантические теги** - `<header>`, `<nav>`, `<main>`, `<footer>` где уместно

### Атрибуты и ARIA
- [ ] **Есть id** - для связи с label, для ARIA атрибутов
- [ ] **Есть aria-label или aria-labelledby** - для скринридеров
- [ ] **Есть aria-describedby** - если нужна подсказка
- [ ] **aria-invalid на невалидные поля** - для доступности
- [ ] **aria-hidden на декоративные элементы** - чтобы не читались
- [ ] **role атрибуты где нужны** - dialog, button, region и т.д.
- [ ] **data-* атрибуты для JS логики** - не использовать class для поиска в JS

### Примеры правильного HTML

```html
<!-- ✅ Хорошо: использован <button> тег -->
<button class="button button--primary" id="submit-btn" aria-label="Отправить форму">
  Отправить
</button>

<!-- ❌ Плохо: <div> вместо <button> -->
<div class="button" onclick="submit()">Отправить</div>

<!-- ✅ Хорошо: input с label -->
<div class="input">
  <label class="input__label" for="email">Email</label>
  <input
    type="email"
    id="email"
    class="input__field"
    placeholder="example@mail.com"
    required
    aria-describedby="email-error"
  />
  <span id="email-error" class="input__error"></span>
</div>

<!-- ❌ Плохо: нет label, нет aria-describedby -->
<input type="email" class="input__field" placeholder="email">
<span class="error">Error message</span>
```

---

## 🎨 РАЗРАБОТКА CSS ЧАСТИ

### Именование по БЕМ
- [ ] **Block** - основной класс компонента `.button`
- [ ] **Element** - части компонента `.button__icon`, `.button__text`
- [ ] **Modifier** - вариации `.button--primary`, `.button--disabled`
- [ ] **Состояния** - как модификаторы `.button--loading`, `.input--error`
- [ ] **Нет каскада** - стили не наследуются вниз по иерархии
- [ ] **Нет id селекторов** - только классы

### Примеры БЕМ

```css
/* ✅ Хорошо: БЕМ структура */
.button { /* Block */ }
.button__icon { /* Element */ }
.button__text { /* Element */ }
.button--primary { /* Modifier */ }
.button--large { /* Modifier */ }
.button--disabled { /* State */ }

/* ❌ Плохо: каскад и неясные имена */
.button { }
.button .icon { } /* каскад */
.button .text { } /* каскад */
.button.active { } /* где это используется? */
#submit-button { } /* id селектор */
```

### Производительность CSS
- [ ] **Не используются дорогие селекторы** - не` .parent > div > span`
- [ ] **Не используются multiple transitions** - `transition: all`
- [ ] **Используется transform и opacity для анимаций** - не width/left/right
- [ ] **Не используются @import** - вместо этого импорт в JS или webpack
- [ ] **CSS переменные для значений повторяющихся** - `--primary-color`

### Примеры правильного CSS

```css
/* ✅ Хорошо: простые селекторы */
.button { }
.button--primary { }
.button__icon { }

/* ❌ Плохо: каскадные селекторы */
.container > .wrapper > .button { }
.form .button { }

/* ✅ Хорошо: использование transform для анимации */
.button:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
}

/* ❌ Плохо: изменение width/height в анимации */
.button:hover {
  width: 120px;
  height: 50px;
}

/* ✅ Хорошо: CSS переменные */
.button {
  background: var(--primary-color);
  padding: var(--button-padding);
}

/* ❌ Плохо: hardcoded значения */
.button {
  background: #007bff;
  padding: 12px 24px;
}
```

### Доступность в CSS
- [ ] **:focus-visible вместо outline: none** - не скрывать фокус
- [ ] **min-height 44px для интерактивных элементов** - для мобильности
- [ ] **prefers-reduced-motion** - без анимаций если нужно
- [ ] **contrast ratio минимум 4.5:1** - для текста
- [ ] **cursor: pointer только на интерактивные элементы**

```css
/* ✅ Хорошо: доступные стили */
.button:focus-visible {
  outline: 2px solid #007bff;
  outline-offset: 2px;
}

.button {
  min-height: 44px; /* для мобильных */
}

@media (prefers-reduced-motion: reduce) {
  .button {
    transition: none;
    animation: none;
  }
}

/* ❌ Плохо: скрыт фокус */
.button {
  outline: none;
  border: none;
}

.button {
  height: 32px; /* слишком маленько */
}
```

---

## ⚙️ РАЗРАБОТКА JS ЧАСТИ

### Инкапсуляция
- [ ] **Компонент управляет своим состоянием** - не глобальное состояние
- [ ] **Состояние не отображается прямо в DOM** - используются классы
- [ ] **События отправляются через EventBus** - не прямые вызовы функций
- [ ] **Нет прямого доступа к приватным свойствам**

### Примеры хорошей инкапсуляции

```javascript
/* ✅ Хорошо: компонент управляет своим состоянием */
class Modal {
  constructor(element) {
    this.element = element;
    this.isOpen = false; // приватное состояние
    this.init();
  }

  open() {
    this.isOpen = true;
    this.element.classList.add('modal--open');
    eventBus.emit('modal:opened', { modal: this });
  }
}

/* ❌ Плохо: глобальное состояние */
let isModalOpen = false;
let currentModal = null;

function openModal(modalId) {
  isModalOpen = true;
  currentModal = modalId;
  document.querySelector('#' + modalId).classList.add('open');
}
```

### Lifecycle методы
- [ ] **init()** - инициализация, установка listeners
- [ ] **render()** - обновление DOM если нужно
- [ ] **destroy()** - очистка, удаление listeners
- [ ] **update()** - обновление состояния и отображения

```javascript
class Component {
  constructor(element) {
    this.element = element;
  }

  init() {
    // Установить listeners и инициализировать
    this.setupListeners();
    this.render();
  }

  setupListeners() {
    this.unlistenClick = DOM.on(this.element, 'click', () => {
      this.handleClick();
    });
  }

  handleClick() {
    // Обработка события
  }

  render() {
    // Обновить DOM если нужно
  }

  update(data) {
    // Обновить состояние и UI
    this.render();
  }

  destroy() {
    // Очистка
    this.unlistenClick?.();
    this.element = null;
  }
}
```

### Производительность JS
- [ ] **Debounce/throttle для resize/scroll** - не на каждое событие
- [ ] **requestAnimationFrame для DOM обновлений** - батчинг
- [ ] **Event delegation где возможно** - не listener на каждый элемент
- [ ] **Нет утечек памяти** - все listeners удаляются в destroy()
- [ ] **Нет бесконечных циклов или рекурсии**

```javascript
/* ✅ Хорошо: debounce для resize */
function debounce(fn, delay) {
  let timeoutId;
  return function(...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
}

window.addEventListener('resize', debounce(() => {
  component.handleResize();
}, 250));

/* ❌ Плохо: вызывается на каждое событие */
window.addEventListener('resize', () => {
  component.handleResize(); // может быть 100+ раз в секунду
});
```

### Тестируемость
- [ ] **Компоненты экспортируют как классы** - легко создать для теста
- [ ] **Нет зависимостей от глобального состояния** - если возможно
- [ ] **Используется dependency injection** - передаются зависимости в конструктор
- [ ] **Написаны unit тесты** - минимум базовые

```javascript
/* ✅ Хорошо: простой для тестирования */
class Button {
  constructor(element, eventBus = new EventBus()) {
    this.element = element;
    this.eventBus = eventBus;
  }

  handleClick() {
    this.eventBus.emit('button:clicked', { button: this });
  }
}

// В тесте
describe('Button', () => {
  test('должна emit событие', () => {
    const mockEventBus = { emit: jest.fn() };
    const button = new Button(element, mockEventBus);
    button.handleClick();
    expect(mockEventBus.emit).toHaveBeenCalled();
  });
});

/* ❌ Плохо: зависит от глобального eventBus */
class Button {
  handleClick() {
    window.eventBus.emit('clicked'); // как мокировать?
  }
}
```

---

## 📚 ДОКУМЕНТАЦИЯ

- [ ] **README.md с примерами** - как использовать компонент
- [ ] **Список всех БЕМ классов** - что означает каждый
- [ ] **Список всех событий** - какие события компонент отправляет
- [ ] **Список всех методов** - публичный API компонента
- [ ] **Примеры использования** - несколько вариантов
- [ ] **Зависимости** - какие утилиты нужны (EventBus, DOM и т.д.)
- [ ] **Поддерживаемые браузеры** - минимальная версия
- [ ] **CHANGELOG** - история изменений, breaking changes

### Пример README

```markdown
# Button Component

## Описание
Универсальная кнопка для всего приложения.

## Использование

### HTML
```html
<button class="button button--primary">
  <svg class="button__icon">...</svg>
  <span class="button__text">Нажми меня</span>
</button>
```

### JavaScript
```javascript
const button = new Button(document.querySelector('.button'));

// Слушаем клики
eventBus.on('button:clicked', (data) => {
  console.log('Кнопка нажата:', data.buttonId);
});

// Методы
button.disable();
button.enable();
button.setLoading(true);
```

## CSS классы

| Класс | Описание |
|-------|---------|
| `.button` | Основная кнопка |
| `.button__icon` | Иконка внутри |
| `.button__text` | Текст |
| `.button--primary` | Основная (синяя) |
| `.button--secondary` | Вторичная (серая) |
| `.button--danger` | Опасная (красная) |
| `.button--disabled` | Отключена |
| `.button--loading` | В процессе загрузки |

## События

### button:clicked
Вызывается когда пользователь нажимает на кнопку.

```javascript
eventBus.on('button:clicked', (data) => {
  console.log(data.buttonId);    // ID кнопки
  console.log(data.timestamp);   // Время клика
});
```

## API

### Методы

#### `disable()`
Отключает кнопку.

#### `enable()`
Включает кнопку.

#### `setLoading(isLoading: boolean)`
Показывает/скрывает spinner загрузки.

#### `destroy()`
Удаляет все listeners и очищает память.

## Браузеры
- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

## Зависимости
- `DOM` утилита
- `EventBus` для событий

## Версия
2.1.0

## Changelog
- **2.1.0** - Добавлены CSS переменные
- **2.0.0** - ⚠️ BREAKING: переименование классов
- **1.0.0** - Начальный релиз
```

---

## 🧪 ТЕСТИРОВАНИЕ

### Unit тесты
- [ ] **Компонент правильно инициализируется**
- [ ] **Методы работают как ожидается**
- [ ] **События испускаются в правильный момент**
- [ ] **CSS классы добавляются/удаляются правильно**
- [ ] **Нет утечек памяти после destroy()**
- [ ] **ARIA атрибуты установлены правильно**

### Пример unit теста

```javascript
describe('Button Component', () => {
  let button, element, eventBus;

  beforeEach(() => {
    // Setup
    element = document.createElement('button');
    element.className = 'button';
    element.id = 'test-btn';
    element.textContent = 'Click';
    document.body.appendChild(element);

    eventBus = new EventBus();
    button = new Button(element, eventBus);
  });

  afterEach(() => {
    // Cleanup
    button.destroy();
    element.remove();
  });

  test('должна испустить событие при клике', () => {
    const spy = jest.fn();
    eventBus.on('button:clicked', spy);

    element.click();

    expect(spy).toHaveBeenCalledWith(
      expect.objectContaining({
        buttonId: 'test-btn'
      })
    );
  });

  test('должна иметь aria-label', () => {
    expect(element.getAttribute('aria-label')).toBe('Click');
  });

  test('должна быть заблокирована после disable()', () => {
    button.disable();
    expect(button.isDisabled).toBe(true);
    expect(element.hasAttribute('disabled')).toBe(true);
  });
});
```

### E2E тесты
- [ ] **Компонент работает в реальном браузере**
- [ ] **Стили загружаются правильно**
- [ ] **JS инициализируется в правильный момент**
- [ ] **Работает на разных браузерах**
- [ ] **Работает на мобильных**

---

## 🚀 ПРОИЗВОДСТВО

### Минификация
- [ ] **CSS минифицирован** - убраны комментарии и пробелы
- [ ] **JS минифицирован** - все названия переменных изменены
- [ ] **HTML может быть минифицирован** - если используется в template

### Версионирование
- [ ] **Следует семантическому версионированию** - major.minor.patch
- [ ] **BREAKING CHANGES указаны** - в CHANGELOG и в README
- [ ] **Подробный CHANGELOG** - что добавилось, что удалилось

### Распространение
- [ ] **Компонент на NPM** - если нужен для других проектов
- [ ] **Документация на сайте** - Storybook или подобное
- [ ] **Примеры использования** - реальные сценарии

---

## 💡TIPS & TRICKS

### Что делать
✅ Использовать методы которые возвращают контекст для chainning
✅ Использовать приватные методы с `_` префиксом или `#`
✅ Документировать публичное API JSDoc комментариями
✅ Избегать jQuery-подобного синтаксиса
✅ Использовать TypeScript для больших проектов

### Чего не делать
❌ Не смешивать логику разных компонентов
❌ Не использовать глобальные переменные в компоненте
❌ Не создавать компоненты через jQuery или другой инструмент
❌ Не копипастить код между компонентами (создать утилиту)
❌ Не писать магические числа - используй CSS переменные и конфиги

### Отладка
- [ ] **Использовать devtools** - инспектировать элементы и DOM
- [ ] **Логировать события** - `eventBus.debug = true`
- [ ] **Проверять классы** - добавляются ли они в правильный момент
- [ ] **Проверять listeners** - они удаляются после destroy()?
- [ ] **Использовать console.time()** - для профилирования производительности

---

## 📊 ФИНАЛЬНАЯ ПРОВЕРКА

Перед тем как отправить компонент в продакшен, проверьте:

- [ ] Работает на всех поддерживаемых браузерах
- [ ] Нет консольных ошибок
- [ ] Доступен для людей с ограничениями (скринридер, клавиатура)
- [ ] Смотрится хорошо на мобильных
- [ ] CSS изолирован (не влияет на другие компоненты)
- [ ] JS нет утечек памяти
- [ ] Документировано в README
- [ ] Есть примеры использования
- [ ] Протестировано в других проектах
- [ ] Код отформатирован и прошел linting
- [ ] Написаны комментарии для сложных моментов
- [ ] Следует стилю гайду проекта
