/*
===========================================
ПРАКТИЧЕСКИЙ ПРИМЕР: СИСТЕМА КОМПОНЕНТОВ
===========================================

Структура проекта:
```
components/
├── Button/
│   ├── Button.html
│   ├── Button.css
│   ├── Button.js
│   └── README.md
├── Modal/
│   ├── Modal.html
│   ├── Modal.css
│   ├── Modal.js
│   └── Modal.test.js
├── Input/
│   ├── Input.html
│   ├── Input.css
│   ├── Input.js
│   └── README.md
└── ...
utils/
├── EventBus.js
├── DOM.js
└── validators.js
index.html - demо страница
```
*/

// ============================================
// 1️⃣ УТИЛИТА: EventBus (шина событий)
// ============================================
// utils/EventBus.js

class EventBus {
  constructor() {
    this.events = {};
    this.debug = false;
  }

  on(event, callback, context = null) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push({ callback, context });
    
    if (this.debug) {
      console.log(`[EventBus] Подписка на событие: ${event}`);
    }
    
    // Вернуть функцию отписки для удобства
    return () => this.off(event, callback);
  }

  emit(event, data) {
    if (this.debug) {
      console.log(`[EventBus] Событие: ${event}`, data);
    }
    
    if (this.events[event]) {
      this.events[event].forEach(({ callback, context }) => {
        callback.call(context, data);
      });
    }
  }

  off(event, callback) {
    if (this.events[event]) {
      this.events[event] = this.events[event].filter(
        item => item.callback !== callback
      );
    }
  }

  destroy() {
    this.events = {};
  }
}

const eventBus = new EventBus();


// ============================================
// 2️⃣ УТИЛИТА: DOM хелпер
// ============================================
// utils/DOM.js

class DOM {
  static query(selector, parent = document) {
    return parent.querySelector(selector);
  }

  static queryAll(selector, parent = document) {
    return Array.from(parent.querySelectorAll(selector));
  }

  static create(tag, className = '', attrs = {}) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    Object.assign(element, attrs);
    return element;
  }

  static addClass(el, ...classes) {
    el.classList.add(...classes);
  }

  static removeClass(el, ...classes) {
    el.classList.remove(...classes);
  }

  static toggleClass(el, className) {
    el.classList.toggle(className);
  }

  static hasClass(el, className) {
    return el.classList.contains(className);
  }

  static on(el, event, handler, options = false) {
    el.addEventListener(event, handler, options);
    // Возвратить функцию удаления listener
    return () => el.removeEventListener(event, handler, options);
  }

  static setText(el, text) {
    el.textContent = text;
  }

  static setHTML(el, html) {
    el.innerHTML = html;
  }

  static getAttr(el, attr) {
    return el.getAttribute(attr);
  }

  static setAttr(el, attr, value) {
    el.setAttribute(attr, value);
  }

  static setData(el, key, value) {
    el.dataset[key] = value;
  }

  static getData(el, key) {
    return el.dataset[key];
  }
}


// ============================================
// 3️⃣ КОМПОНЕНТ: Button (простой)
// ============================================
// components/Button/Button.js

class Button {
  constructor(element) {
    this.element = element;
    this.isDisabled = false;
    
    this.init();
  }

  init() {
    // Гарантируем, что это действительно кнопка
    if (this.element.tagName !== 'BUTTON') {
      console.warn('Button компонент ожидает <button> элемент');
    }

    // Установим ARIA атрибуты для доступности
    if (!this.element.getAttribute('aria-label')) {
      this.element.setAttribute('aria-label', this.element.textContent);
    }

    // Слушаем клики
    this.unlistenClick = DOM.on(this.element, 'click', (e) => {
      this.handleClick(e);
    });
  }

  handleClick(event) {
    if (this.isDisabled) {
      event.preventDefault();
      event.stopPropagation();
      return;
    }

    // Отправляем событие в шину
    eventBus.emit('button:clicked', {
      buttonElement: this.element,
      buttonId: this.element.id,
      timestamp: Date.now()
    });
  }

  disable() {
    this.isDisabled = true;
    this.element.setAttribute('disabled', 'disabled');
    DOM.addClass(this.element, 'button--disabled');
  }

  enable() {
    this.isDisabled = false;
    this.element.removeAttribute('disabled');
    DOM.removeClass(this.element, 'button--disabled');
  }

  setLoading(isLoading) {
    if (isLoading) {
      this.disable();
      DOM.addClass(this.element, 'button--loading');
      this.element.setAttribute('aria-busy', 'true');
    } else {
      this.enable();
      DOM.removeClass(this.element, 'button--loading');
      this.element.setAttribute('aria-busy', 'false');
    }
  }

  destroy() {
    this.unlistenClick?.();
  }
}


// ============================================
// 4️⃣ КОМПОНЕНТ: Input (с валидацией)
// ============================================
// components/Input/Input.js

class Input {
  constructor(element) {
    this.element = element;
    this.wrapper = this.element.closest('.input') || this.element;
    this.errorElement = DOM.query('.input__error', this.wrapper);
    this.value = this.element.value;
    this.validators = [];

    this.init();
  }

  init() {
    // Установим ARIA атрибуты
    if (!this.element.getAttribute('aria-label')) {
      const label = DOM.query('label[for="' + this.element.id + '"]');
      if (label) {
        this.element.setAttribute('aria-label', label.textContent);
      }
    }

    // Слушаем изменения с debounce
    this.unlistenInput = DOM.on(this.element, 'input', (e) => {
      this.value = e.target.value;
      this.clearError();
      this.validate();
    });

    // Слушаем blur для фокуса
    this.unlistenBlur = DOM.on(this.element, 'blur', () => {
      this.validate();
    });
  }

  addValidator(validatorFn) {
    this.validators.push(validatorFn);
  }

  validate() {
    let isValid = true;
    let errorMessage = '';

    for (const validator of this.validators) {
      const result = validator(this.value);
      if (result !== true) {
        isValid = false;
        errorMessage = result;
        break;
      }
    }

    if (!isValid) {
      this.setError(errorMessage);
      eventBus.emit('input:invalid', {
        input: this.element,
        message: errorMessage,
        value: this.value
      });
      return false;
    } else {
      this.clearError();
      eventBus.emit('input:valid', {
        input: this.element,
        value: this.value
      });
      return true;
    }
  }

  setError(message) {
    DOM.addClass(this.wrapper, 'input--error');
    DOM.addClass(this.element, 'input__field--error');
    this.element.setAttribute('aria-invalid', 'true');
    
    if (this.errorElement) {
      DOM.setText(this.errorElement, message);
    } else {
      // Создаем элемент ошибки если его нет
      const error = DOM.create('span', 'input__error');
      DOM.setText(error, message);
      this.wrapper.appendChild(error);
      this.errorElement = error;
    }
  }

  clearError() {
    DOM.removeClass(this.wrapper, 'input--error');
    DOM.removeClass(this.element, 'input__field--error');
    this.element.setAttribute('aria-invalid', 'false');
    if (this.errorElement) {
      DOM.setText(this.errorElement, '');
    }
  }

  getValue() {
    return this.value;
  }

  setValue(value) {
    this.element.value = value;
    this.value = value;
    this.clearError();
  }

  focus() {
    this.element.focus();
  }

  destroy() {
    this.unlistenInput?.();
    this.unlistenBlur?.();
  }
}


// ============================================
// 5️⃣ КОМПОНЕНТ: Modal (со сложной логикой)
// ============================================
// components/Modal/Modal.js

class Modal {
  constructor(element) {
    this.element = element;
    this.isOpen = false;
    this.closeButton = DOM.query('[data-modal-close]', this.element);
    this.overlay = DOM.query('.modal__overlay', this.element);
    this.content = DOM.query('.modal__content', this.element);
    this.animationDuration = 300; // мс

    this.init();
  }

  init() {
    // ARIA атрибуты
    this.element.setAttribute('role', 'dialog');
    this.element.setAttribute('aria-modal', 'true');
    this.element.setAttribute('aria-hidden', 'true');

    // Обработчики
    this.unlistenClose = DOM.on(this.closeButton, 'click', () => this.close());
    this.unlistenOverlay = DOM.on(this.overlay, 'click', (e) => {
      if (e.target === this.overlay) this.close();
    });

    // Закрытие по Escape
    this.unlistenKeyboard = DOM.on(document, 'keydown', (e) => {
      if (e.key === 'Escape' && this.isOpen) {
        this.close();
      }
    });

    // Слушаем глобальные события
    this.unlistenGlobal = eventBus.on('modal:open-request', (data) => {
      if (data.modalId === this.element.id) {
        this.open();
      }
    });
  }

  open() {
    if (this.isOpen) return;

    this.isOpen = true;
    DOM.addClass(this.element, 'modal--open');
    this.element.setAttribute('aria-hidden', 'false');

    // Блокируем скролл body
    document.body.style.overflow = 'hidden';

    // Анимация
    this.element.offsetHeight; // trigger reflow
    DOM.addClass(this.element, 'modal--animated');

    // Фокус в модальное окно
    this.content.focus();

    // Событие
    eventBus.emit('modal:opened', { modal: this.element });
  }

  close() {
    if (!this.isOpen) return;

    this.isOpen = false;
    DOM.removeClass(this.element, 'modal--animated');
    
    setTimeout(() => {
      DOM.removeClass(this.element, 'modal--open');
      this.element.setAttribute('aria-hidden', 'true');
      document.body.style.overflow = 'auto';

      eventBus.emit('modal:closed', { modal: this.element });
    }, this.animationDuration);
  }

  setContent(html) {
    const contentBody = DOM.query('.modal__body', this.content);
    if (contentBody) {
      DOM.setHTML(contentBody, html);
    }
  }

  destroy() {
    this.unlistenClose?.();
    this.unlistenOverlay?.();
    this.unlistenKeyboard?.();
    this.unlistenGlobal?.();
  }
}


// ============================================
// 6️⃣ ИНИЦИАЛИЗАЦИЯ И ИСПОЛЬЗОВАНИЕ
// ============================================
// index.js

class App {
  constructor() {
    this.components = [];
    this.init();
  }

  init() {
    // Инициализируем все кнопки
    DOM.queryAll('.button').forEach(buttonEl => {
      this.components.push(new Button(buttonEl));
    });

    // Инициализируем все поля ввода
    DOM.queryAll('.input__field').forEach(inputEl => {
      const input = new Input(inputEl);
      
      // Добавляем валидаторы
      input.addValidator((value) => {
        if (!value.trim()) {
          return 'Поле не должно быть пустым';
        }
        return true;
      });

      input.addValidator((value) => {
        if (value.length < 3) {
          return 'Минимум 3 символа';
        }
        return true;
      });

      this.components.push(input);
    });

    // Инициализируем все модальные окна
    DOM.queryAll('[role="dialog"]').forEach(modalEl => {
      this.components.push(new Modal(modalEl));
    });

    // Обработчики событий
    this.setupEventHandlers();
  }

  setupEventHandlers() {
    // Когда кнопка нажата
    eventBus.on('button:clicked', (data) => {
      const buttonId = data.buttonId;

      // Если это кнопка "Открыть модаль"
      if (buttonId === 'open-modal-btn') {
        eventBus.emit('modal:open-request', { modalId: 'modal-1' });
      }

      // Если это кнопка "Отправить форму"
      if (buttonId === 'submit-btn') {
        this.handleFormSubmit();
      }

      console.log('Кнопка нажата:', buttonId);
    });

    // Когда поле валидно
    eventBus.on('input:valid', (data) => {
      console.log('Поле валидно:', data.value);
    });

    // Когда модаль открылась
    eventBus.on('modal:opened', (data) => {
      console.log('Модаль открыта');
    });
  }

  handleFormSubmit() {
    const inputs = DOM.queryAll('.input__field');
    let isFormValid = true;

    inputs.forEach(inputEl => {
      const input = this.components.find(c => c.element === inputEl);
      if (input && !input.validate()) {
        isFormValid = false;
      }
    });

    if (isFormValid) {
      console.log('Форма валидна, отправляем данные');
      // Отправляем на сервер
    } else {
      console.log('Форма содержит ошибки');
    }
  }

  destroy() {
    this.components.forEach(component => {
      if (component.destroy) {
        component.destroy();
      }
    });
    this.components = [];
    eventBus.destroy();
  }
}

// Инициализируем приложение когда DOM готов
document.addEventListener('DOMContentLoaded', () => {
  window.app = new App();
});


// ============================================
// 7️⃣ ПРИМЕРЫ ТЕСТИРОВАНИЯ
// ============================================
// components/Button/Button.test.js

describe('Button Component', () => {
  let button;
  let element;

  beforeEach(() => {
    // Setup
    element = document.createElement('button');
    element.id = 'test-button';
    element.className = 'button';
    element.textContent = 'Click me';
    document.body.appendChild(element);

    button = new Button(element);
  });

  afterEach(() => {
    // Cleanup
    button.destroy();
    element.remove();
  });

  test('должна вызвать событие при клике', () => {
    const spy = jest.fn();
    eventBus.on('button:clicked', spy);

    element.click();

    expect(spy).toHaveBeenCalledWith(
      expect.objectContaining({
        buttonId: 'test-button',
        timestamp: expect.any(Number)
      })
    );

    eventBus.off('button:clicked', spy);
  });

  test('должна быть заблокирована когда disable() вызывается', () => {
    button.disable();

    expect(button.isDisabled).toBe(true);
    expect(element.hasAttribute('disabled')).toBe(true);
    expect(element.classList.contains('button--disabled')).toBe(true);
  });

  test('должна иметь aria-label', () => {
    expect(element.getAttribute('aria-label')).toBe('Click me');
  });

  test('не должна вызвать событие если заблокирована', () => {
    const spy = jest.fn();
    eventBus.on('button:clicked', spy);

    button.disable();
    element.click();

    expect(spy).not.toHaveBeenCalled();

    eventBus.off('button:clicked', spy);
  });
});


// ============================================
// 8️⃣ ПРИМЕРЫ ИСПОЛЬЗОВАНИЯ В HTML
// ============================================

/*

<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Система компонентов</title>
  <link rel="stylesheet" href="styles/Button.css">
  <link rel="stylesheet" href="styles/Input.css">
  <link rel="stylesheet" href="styles/Modal.css">
</head>
<body>

<!-- КНОПКА: простой компонент -->
<button id="open-modal-btn" class="button button--primary">
  Открыть модаль
</button>

<!-- INPUT: поле с валидацией -->
<div class="input">
  <input
    type="text"
    id="name-input"
    class="input__field"
    placeholder="Введите имя"
    aria-describedby="name-error"
  />
  <span id="name-error" class="input__error"></span>
</div>

<!-- MODAL: модальное окно -->
<div id="modal-1" class="modal" role="dialog" aria-modal="true">
  <div class="modal__overlay"></div>
  <div class="modal__content">
    <button class="modal__close" data-modal-close" aria-label="Закрыть">×</button>
    <div class="modal__body">
      <h2>Заголовок модали</h2>
      <p>Содержимое модали</p>
    </div>
  </div>
</div>

<!-- JAVASCRIPT -->
<script src="utils/EventBus.js"></script>
<script src="utils/DOM.js"></script>
<script src="components/Button/Button.js"></script>
<script src="components/Input/Input.js"></script>
<script src="components/Modal/Modal.js"></script>
<script src="index.js"></script>

</body>
</html>

*/
