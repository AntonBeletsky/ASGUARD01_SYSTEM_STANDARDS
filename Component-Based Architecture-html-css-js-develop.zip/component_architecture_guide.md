# Архитектура компонентов HTML/CSS/JS: Современные практики

## 1. ПРОБЛЕМА: Фрагментация кода

При разработке виджетов код естественным образом разбивается на три слоя:
```
❌ ДО - Хаос
├── html/
│   ├── button.html (структура)
│   ├── modal.html
│   └── card.html
├── css/
│   ├── button.css (стили)
│   ├── modal.css
│   └── styles.css (глобальные стили)
└── js/
    ├── button.js (поведение)
    ├── modal.js
    └── app.js (общая логика)
```

**Проблемы:**
- Сложно найти все части одного компонента
- Нарушение принципа DRY (Don't Repeat Yourself)
- Конфликты имен (class="button" используется в 5 местах)
- Трудное масштабирование проекта
- Сложное переиспользование компонента в других проектах

---

## 2. РЕШЕНИЕ: Component-Based Architecture

### 2.1 Модульная структура (File-based Encapsulation)

```
✅ ПОСЛЕ - Организованная структура
components/
├── Button/
│   ├── Button.html
│   ├── Button.css
│   ├── Button.js
│   └── README.md
├── Modal/
│   ├── Modal.html
│   ├── Modal.css
│   ├── Modal.js
│   └── Modal.test.js
├── Card/
│   └── ...
└── DataTable/
    └── ...
```

**Преимущества:**
- 👁️ **Видимость** - все части компонента в одной папке
- 🔄 **Переиспользование** - скопируй папку, используй везде
- 🧪 **Тестируемость** - каждый компонент изолирован
- 🤝 **Коллаборация** - разные разработчики работают с разными компонентами

---

## 3. ПРИНЦИПЫ КАЧЕСТВЕННОЙ РАЗРАБОТКИ

### 3.1 BEM (Block Element Modifier) - CSS Именование

**Проблема:**
```css
/* ❌ Конфликты имен */
.button { color: blue; }
.button { color: red; } /* переписывает предыдущее */
.active { /* не понять, для чего нужен */ }
```

**Решение БЕМ:**
```css
/* ✅ Однозначные имена */
.button { /* Block - главный компонент */ }
.button__icon { /* Element - часть компонента */ }
.button__text { /* Element */ }
.button--primary { /* Modifier - вариант */ }
.button--disabled { /* Modifier - состояние */ }
```

**Пример HTML:**
```html
<button class="button button--primary">
  <svg class="button__icon"></svg>
  <span class="button__text">Нажми меня</span>
</button>
```

**Пример CSS:**
```css
.button {
  padding: 12px 24px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 600;
}

.button__icon {
  width: 20px;
  height: 20px;
  margin-right: 8px;
  display: inline-block;
}

.button--primary {
  background: #007bff;
  color: white;
}

.button--primary:hover {
  background: #0056b3;
}

.button--disabled {
  opacity: 0.5;
  cursor: not-allowed;
  pointer-events: none;
}
```

### 3.2 CSS-in-JS / CSS Modules (для изоляции стилей)

**Проблема cascading-цепочки:**
```css
/* ❌ Глобальные стили влияют везде */
div { margin: 0; } /* может сломать наш компонент */
.card { border: 1px solid #ccc; }
/* непредсказуемое наследование */
```

**Решение 1 - CSS Modules (Native):**
```css
/* Button.module.css */
.button {
  padding: 12px 24px;
  border: none;
}

.primary {
  background: #007bff;
  color: white;
}
```

```html
<!-- Button.html -->
<button class="button primary">
  <!-- автоматически становится .Button_button__2a3b .Button_primary__4c5d -->
</button>
```

```javascript
// Button.js
import styles from './Button.module.css';

const button = document.createElement('button');
button.className = styles.button;
button.classList.add(styles.primary);
```

**Решение 2 - Shadow DOM (Web Components):**
```javascript
class CustomButton extends HTMLElement {
  constructor() {
    super();
    const shadow = this.attachShadow({ mode: 'open' });
    
    // Стили полностью изолированы внутри Shadow DOM
    shadow.innerHTML = `
      <style>
        :host {
          --button-bg: blue;
          --button-color: white;
        }
        
        button {
          background: var(--button-bg);
          color: var(--button-color);
          padding: 12px 24px;
          border: none;
          cursor: pointer;
        }
      </style>
      <button>
        <slot></slot>
      </button>
    `;
  }
}

customElements.define('custom-button', CustomButton);
```

### 3.3 Инкапсуляция состояния (State Management)

**Проблема - глобальное состояние:**
```javascript
// ❌ Плохо - никто не знает откуда берется модальное окно
let isModalOpen = false;

function openModal() {
  isModalOpen = true;
  // ...
}
```

**Решение - State в компоненте:**
```javascript
// Modal.js - Компонент отвечает за свое состояние
class Modal {
  constructor(element) {
    this.element = element;
    this.isOpen = false;
    this.overlay = this.element.querySelector('.modal__overlay');
    this.closeBtn = this.element.querySelector('.modal__close');
    
    this.init();
  }
  
  init() {
    this.closeBtn.addEventListener('click', () => this.close());
    this.overlay.addEventListener('click', (e) => {
      if (e.target === this.overlay) this.close();
    });
  }
  
  open() {
    this.isOpen = true;
    this.element.classList.add('modal--open');
    this.element.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }
  
  close() {
    this.isOpen = false;
    this.element.classList.remove('modal--open');
    this.element.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = 'auto';
  }
}

// Использование - четко видна структура
const modal = new Modal(document.querySelector('.modal'));
modal.open();
```

### 3.4 Event-Driven Architecture (Событийный подход)

**Проблема - прямые вызовы:**
```javascript
// ❌ Компоненты жестко связаны
button.addEventListener('click', () => {
  modal.open();
  analytics.track('button-clicked');
  logger.log('Opening modal');
  // ...много всего
});
```

**Решение - Event Bus:**
```javascript
// EventBus.js - простой паттерн публикации событий
class EventBus {
  constructor() {
    this.events = {};
  }
  
  on(event, callback) {
    if (!this.events[event]) {
      this.events[event] = [];
    }
    this.events[event].push(callback);
  }
  
  emit(event, data) {
    if (this.events[event]) {
      this.events[event].forEach(callback => callback(data));
    }
  }
  
  off(event, callback) {
    if (this.events[event]) {
      this.events[event] = this.events[event].filter(cb => cb !== callback);
    }
  }
}

const eventBus = new EventBus();

// Button.js - компонент только отправляет событие
class Button {
  constructor(element) {
    this.element = element;
    this.element.addEventListener('click', () => {
      eventBus.emit('button:clicked', { buttonId: this.element.id });
    });
  }
}

// Modal.js - слушает события других компонентов
class Modal {
  constructor(element) {
    this.element = element;
    
    eventBus.on('button:clicked', (data) => {
      if (data.buttonId === 'open-modal-btn') {
        this.open();
      }
    });
  }
  
  open() { /* ... */ }
}

// Analytics.js - отдельно слушает события
eventBus.on('button:clicked', (data) => {
  console.log('Tracked:', data);
});
```

---

## 4. BEST PRACTICES СОВРЕМЕННОЙ РАЗРАБОТКИ

### 4.1 Документирование компонента (README)

```markdown
# Button Component

## Описание
Универсальная кнопка для всего приложения.

## Использование
```html
<button class="button button--primary">
  <svg class="button__icon"><!-- icon --></svg>
  <span class="button__text">Текст</span>
</button>
```

## Модификаторы
- `button--primary` - основная кнопка (синяя)
- `button--secondary` - вторичная кнопка (серая)
- `button--danger` - опасное действие (красная)
- `button--disabled` - заблокирована

## CSS переменные
```css
--button-primary-bg: #007bff;
--button-primary-hover: #0056b3;
--button-border-radius: 4px;
--button-padding: 12px 24px;
```

## Поддерживаемые браузеры
- Chrome 90+
- Firefox 88+
- Safari 14+

## Зависимости
Нет

## Тестирование
```bash
npm test components/Button
```
```

### 4.2 Тестирование компонентов

```javascript
// Button.test.js
describe('Button Component', () => {
  let button;
  
  beforeEach(() => {
    document.body.innerHTML = `
      <button class="button button--primary">Click me</button>
    `;
    button = new Button(document.querySelector('.button'));
  });
  
  test('должна вызвать click event', () => {
    const clickSpy = jest.fn();
    button.element.addEventListener('click', clickSpy);
    
    button.element.click();
    
    expect(clickSpy).toHaveBeenCalled();
  });
  
  test('должна иметь правильный класс', () => {
    expect(button.element.classList.contains('button')).toBe(true);
    expect(button.element.classList.contains('button--primary')).toBe(true);
  });
  
  test('должна быть доступна (accessible)', () => {
    expect(button.element.getAttribute('aria-label')).not.toBeNull();
  });
});
```

### 4.3 Версионирование и совместимость

```json
{
  "componentVersion": "2.1.0",
  "compatibilityBreaking": false,
  "changelog": {
    "2.1.0": "Добавлены CSS переменные для кастомизации",
    "2.0.0": "⚠️ BREAKING: Переименован класс с 'btn' на 'button'",
    "1.0.0": "Начальный релиз"
  }
}
```

### 4.4 Производительность (Performance)

**CSS:**
```css
/* ✅ ХОРОШО - одна перекраска */
.button {
  transition: background-color 0.3s ease;
}

.button:hover {
  background-color: #0056b3;
}

/* ❌ ПЛОХО - множественные перекраски */
.button:hover {
  background: #0056b3;
  border-radius: 8px;
  width: 120px;
  height: 50px;
}
```

**JavaScript:**
```javascript
// ❌ ПЛОХО - множественные обновления DOM
for (let i = 0; i < 1000; i++) {
  element.style.left = i + 'px'; // 1000 раз перерисовывает
}

// ✅ ХОРОШО - батчинг обновлений
requestAnimationFrame(() => {
  elements.forEach(el => {
    el.style.left = el.dataset.position + 'px';
  });
});
```

### 4.5 Доступность (A11y)

```html
<!-- ✅ Правильно -->
<button class="button" type="button" aria-label="Открыть меню">
  <svg aria-hidden="true"><!-- icon --></svg>
</button>

<!-- ❌ Неправильно -->
<div class="button" onclick="openMenu()">
  <svg><!-- icon --></svg>
</div>
```

```css
/* Поддержка для пользователей с vestibular disorders */
@media (prefers-reduced-motion: reduce) {
  .button {
    transition: none;
    animation: none;
  }
}
```

---

## 5. ВЫБОР ИНСТРУМЕНТА: Ванильный JS vs Framework

### Когда использовать Vanilla (HTML/CSS/JS):
✅ Маленькие проекты / лендинги  
✅ Максимальный контроль и производительность  
✅ Нет критичной реактивности  
✅ Компоненты должны работать везде  

### Когда использовать React/Vue/Svelte:
✅ Сложная логика и состояние  
✅ Частые обновления данных  
✅ Большая команда разработчиков  
✅ Нужна переиспользуемость в других проектах React  

---

## 6. ЧЕКЛИСТ КАЧЕСТВЕННОГО КОМПОНЕНТА

- [ ] **Структура** - модульная папка с HTML/CSS/JS
- [ ] **Имена** - используется БЕМ или другая консистентная система
- [ ] **Состояние** - инкапсулировано внутри компонента
- [ ] **События** - использует event bus или custom events
- [ ] **Стили** - изолированы (CSS Modules или Shadow DOM)
- [ ] **Документация** - README с примерами использования
- [ ] **Тесты** - unit тесты и e2e тесты
- [ ] **Производительность** - оптимизированы переходы/анимации
- [ ] **Доступность** - ARIA атрибуты, семантический HTML
- [ ] **Браузеры** - указано минимальная версия поддержки
- [ ] **Версионирование** - следует семантическому версионированию

---

## 7. ПРИМЕРЫ РЕАЛЬНЫХ ПАТТЕРНОВ

### Паттерн 1: Простой компонент (без состояния)

```
Button/ - простая кнопка
├── Button.html - разметка
├── Button.css - стили
├── Button.js - минимальная логика (евенты)
└── README.md
```

### Паттерн 2: Сложный компонент (со состоянием)

```
Modal/ - модальное окно
├── Modal.html - разметка
├── Modal.css - стили
├── Modal.js - управление состоянием
├── Modal.test.js - тесты
├── modal.config.js - конфигурация
└── README.md
```

### Паттерн 3: Система компонентов (Design System)

```
ds/ - Design System
├── components/
│   ├── Button/
│   ├── Input/
│   ├── Modal/
│   └── ...
├── utils/
│   ├── EventBus.js
│   ├── DOM.js
│   └── validators.js
├── styles/
│   ├── variables.css
│   ├── typography.css
│   └── reset.css
├── docs/
│   ├── index.html
│   └── examples.html
└── package.json
```

---

## ИТОГИ

**Ключевые принципы качественной разработки компонентов:**

1. **Модульность** - каждый компонент в своей папке
2. **Изоляция** - компоненты не влияют друг на друга
3. **Консистентность** - единая система имен (БЕМ)
4. **Тестируемость** - компоненты легко тестировать
5. **Документированность** - README и комментарии
6. **Производительность** - оптимизированные стили и JS
7. **Доступность** - ARIA и семантический HTML
8. **Масштабируемость** - легко добавлять новые компоненты

**Результат:**
- Вы знаете где всё находится
- Легко переиспользовать компоненты
- Просто подключить компонент к другому проекту
- Новые разработчики быстро разбираются в коде
- Компоненты работают как предсказуемо
