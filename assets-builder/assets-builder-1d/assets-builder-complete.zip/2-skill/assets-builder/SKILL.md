---
name: assets-builder
description: Merge and richly document a front-end project's scattered CSS and JS files (nested across many folders, some shared across pages, some page-specific) into two single, well-commented dist files (style.css / scripts.js) before selling a template. Runs scripts/assets-builder.py to build a cross-page dependency graph, detect real conflicts (duplicate CSS selectors, colliding JS function names), run recursive "domino" impact analysis, and optionally verify actual class/function usage via a cached JSON map. Use this skill whenever the user wants to merge, bundle, consolidate, or collect CSS/JS from a multi-page HTML project into one file each; wants to prepare a template for marketplace sale (ThemeForest, TemplateMonster, Envato, CodeCanyon); asks which CSS classes or JS functions are actually used; mentions "assets-builder" by name; or in Russian describes this as "собрать/смержить/объединить css и js в один файл" or "подготовить шаблон к продаже" - even without using the word "bundle".
---

# assets-builder

## Principle

`scripts/assets-builder.py` is a deterministic, fully tested engine: file discovery, HTML/CSS/JS parsing, dependency graph, domino analysis, conflict detection, build, report. **All of this mechanics runs inside the script, not in the model's reasoning** — don't parse HTML/CSS/JS by hand and don't try to reproduce the dependency graph in context, even for small projects. The model's role is orchestration, judgment in ambiguous spots, and clear communication with the user.

Script dependencies: `beautifulsoup4`, `tinycss2`. If running the script raises `ModuleNotFoundError`, install them first:
```bash
pip install beautifulsoup4 tinycss2 --break-system-packages
```

The script always excludes `dist/**`, `.git/**`, `node_modules/**` from analysis (the tool's own output must never feed back into it on a re-run).

## Workflow

### WF-1 — determine the project root and mode
Take the project path from context (uploaded files / working directory). If the user hasn't said whether they need the extended usage analysis, start with `--mode basic` — it's faster and needs no explanation.

### WF-2 — scan (safe dry-run, writes nothing)
```bash
python scripts/assets-builder.py scan --project <path> --mode basic \
  --report /tmp/scan-report.md --report-json /tmp/scan-report.json
```
Read `/tmp/scan-report.json`. Exit code `1` means "high-severity conflicts were found" — this is not a runtime error, it's a signal to go to WF-3 before building anything.

### WF-3 — mandatory stopping point
Show the user a short summary: file counts, the shared/page-specific/orphan/vendor breakdown, and any conflicts found.

**A hard rule, not to be overridden by the tone of the conversation**: if `report["conflicts"]["css"]` or `report["conflicts"]["js"]` contains at least one entry with `"severity": "high"`, OR `report["conflicts"]["jsOrder"]` is non-empty — **do not run `build` silently**. Describe the specific conflict in plain language (selector/function name, which files, what will actually diverge when merged) and ask the user how to proceed: keep both variants with an explicit warning (default), use one file as the source of truth, or abort the build (`--on-conflict fail` / `--on-order-conflict fail`, exit codes 2 and 3 respectively). `low`/`medium` conflicts don't block — mention them in one line in the final summary.

Detailed rules by type are in `references/conflict-playbook.md`.

### WF-4 — build
After confirmation (or immediately, if there were no blocking conflicts):
```bash
python scripts/assets-builder.py build --project <path> \
  --out-css dist/style.css --out-js dist/scripts.js \
  --mode basic --comment-lang en \
  --report dist/build-report.md --report-json dist/build-report.json
```
For the extended mode (real class/function usage verification), add `--mode extended` — slower on large projects, but gives `usage.unusedCss` / `usage.dynamicSuspectCss` / `usage.unusedJs` in the report. `--comment-lang en` is the default and usually the right choice: a template is almost always sold internationally; `ru` exists, but only switch to it if the user explicitly asks for Russian-language comments.

The full flag table is in `references/cli-reference.md`.

### WF-5 — review the result before showing it to the user
Open `dist/build-report.md`. If the script's heuristic looks questionable for a specific file (for example, a file clearly looks like a base/reset file but got tagged `page-specific` because only one page happens to reference it in this project) — don't stay silent about it and don't rewrite the classification by hand; add a clarifying note to your reply to the user instead. This is exactly the place where the model's judgment adds value on top of the deterministic analysis.

### WF-6 — final answer
Show `style.css` and `scripts.js` via `present_files`. In text — briefly, not a full retelling of the report:
1. What was merged (how many files → 2 files, how many fewer HTTP requests).
2. What conflicts came up and how they were resolved (or what was left with a warning).
3. **An explicit list of external/CDN resources** (`report["externalAssets"]`) — they weren't merged in and must stay in the HTML by hand. Without this point, the result won't work "out of the box".
4. If `extended` mode was used — how much potentially unused code was found, and that it was NOT removed automatically (unless `--strip-unused` was requested).

## Invariants (never violated regardless of how the user phrases the request)

- Never delete code silently. `--strip-unused` — only on an explicit request in the current conversation.
- Never pick a JS order on a `jsOrder` conflict without the user's confirmation (see WF-3).
- Items with status `dynamic-suspect` are never offered up for removal, even if the user agreed to `--strip-unused` for everything else — the script already guarantees this on its own side, but don't promise the user removal of something the script flags as `dynamic-suspect`.

## Known implementation limitations (be upfront about these if the user runs into them)

- `--js-parser ast` is not implemented — only the heuristic (regex-based) JS parser works. For non-standard syntax (e.g. a class method as the only top-level definition) conflicts/usage may be incomplete.
- The `vendor → shared → page-specific` grouping in `scripts.js` may differ from the original `<script>` order on a specific page if that page's one page-specific file came before the shared file in the HTML. Genuine order contradictions *between* pages are still caught either way (`jsOrder`).
- `--verbose` doesn't currently add any extra detail beyond the normal output.

## Reference material (read as needed, not on every run)

- `references/cli-reference.md` — full flag table and exit codes.
- `references/cache-schema.md` — the structure of `build-report.json` and `.assets-builder-cache.json`.
- `references/comment-templates.md` — the exact format of the comment headers in `style.css`/`scripts.js`.
- `references/conflict-playbook.md` — the detailed "severity + type → action" rules.
- `references/sample-build-report.md` — a worked real report with an example final answer to the user.
