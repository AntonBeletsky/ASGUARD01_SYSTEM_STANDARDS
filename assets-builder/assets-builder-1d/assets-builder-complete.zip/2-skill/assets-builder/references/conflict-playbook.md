# Conflict playbook

Rules of the form "if severity=X and type=Y → action Z". The source of truth for the severity levels themselves is the implementation in `scripts/assets-builder.py` (the `detect_css_conflicts`, `detect_js_conflicts`, `detect_js_order_conflicts` functions), not intuition.

## CSS conflicts (`conflicts.css[]`)

Severity is computed from the overlap of CSS *properties* between occurrences of the same selector across files — not from the rule's text as a whole.

| severity | Condition | Model's action |
|---|---|---|
| `low` | All occurrences are identical, OR the overlapping properties agree in value | Doesn't block. One line in the final summary if the user asks about conflicts — otherwise can be skipped |
| `medium` | Different, non-overlapping properties (the cascade will combine both without loss) | Doesn't block. Mention in the summary in one line: "`.btn` is defined in 2 files with different properties, no actual conflict" |
| `high` | An overlapping property with a different value (a real "last one in the cascade wins" risk) | **Blocks** (see WF-3 in `SKILL.md`). Show the user both values and which file comes later in the final order (meaning it wins by default) |

## JS conflicts (`conflicts.js[]`)

There is no `medium` level for JS — a name collision in the global scope is either a harmless duplicate or a real overwrite risk.

| severity | Condition | Model's action |
|---|---|---|
| `low` | Identical body (by a first-lines fingerprint) — an exact duplicate | Doesn't block |
| `high` | Same name, different body — the last definition silently wins when concatenated | **Blocks**. Show both files, ask: keep as-is with an explicit warning, use one version as the source of truth (in which case suggest removing the other definition in the source manually — the script itself doesn't edit source files), or abort (`--on-conflict fail`) |

## Order conflicts (`conflicts.jsOrder[]`)

Only occur when TWO DIFFERENT pages require an opposite order for the same pair of files. A single-page ordering difference (for example, caused by the vendor→shared→page-specific grouping) does not show up in `jsOrder` — see the known limitation noted in `SKILL.md`.

**Always blocks**, regardless of it not carrying a `severity` field — the mere presence of an entry in `jsOrder` already means "auto-sorting cannot satisfy both pages". Show the user both pages and both required orders (`page_a`/`order_a`, `page_b`/`order_b`), explain that the file will still get a best-effort order with a warning banner either way (see `references/comment-templates.md`), and ask whether that's acceptable or the build should be aborted (`--on-order-conflict fail`, exit code `3`).

## `--strip-unused` (extended mode only)

| Status in `usage.*` | What the flag does |
|---|---|
| `unused` | Removed, replaced with a `/* removed by --strip-unused: ... */` marker |
| `dynamic-suspect` | **Never removed** — this is a guarantee at the level of the script's code (see `strip_unused_css_rules`), not just a convention. Don't promise the user the script will remove `dynamic-suspect` items, even if they insist — offer to show the list and decide by hand instead |
| `used` | Not flagged as a candidate at all |

Never turn on `--strip-unused` by default — only if the user explicitly asked for it in the current conversation.

## What is NOT part of the blocking gate

File classification (`shared`/`page-specific`/`orphan`/`vendor`) does not by itself require stopping — even if it looks heuristically questionable (see WF-5 in `SKILL.md`), that calls for a clarifying note in the reply, not a question to the user before building.
