# Worked example: a real run on the test fixture

Below is the actual `build-report.json` produced while validating `assets-builder.py` (see `fixture-example.tar.gz` in the script's deliverables) — not a made-up sample. 3 pages (`index.html`, `about.html`, `shop.html`), 6 CSS and 3 JS files, `--mode extended`.

## Key fields of the report

```json
{
  "meta": { "mode": "extended", "totalFiles": 12, "htmlPages": 3, "cssFiles": 6, "jsFiles": 3 },
  "classification": {
    "shared": ["assets/css/base.css", "assets/css/print.css", "assets/css/shared.css", "assets/js/main.js"],
    "page-specific": ["assets/css/pages/shop.css", "assets/js/pages/shop.js"],
    "orphan": ["assets/css/unused.css"],
    "vendor": ["assets/css/vendor/tiny-lib.min.css", "assets/js/vendor/tiny-lib.min.js"]
  },
  "conflicts": {
    "css": [
      {"name": ".btn", "files": ["...shop.css", "...shared.css"], "severity": "medium"},
      {"name": ".card", "files": ["...shop.css", "...shared.css"], "severity": "high",
       "detail": "overlapping properties with different values: ['padding']"},
      {"name": ".container", "files": ["base.css","print.css","shared.css"], "severity": "low"}
    ],
    "js": [{"name": "initApp", "files": ["main.js", "shop.js"], "severity": "high"}],
    "jsOrder": []
  },
  "externalAssets": [{"page": "index.html", "href": "https://cdn.example.com/analytics.js", "kind": "js-src"}],
  "usage": {
    "unusedCss": [".never-linked", ".tl-col", ".tl-row", ".unused-badge"],
    "dynamicSuspectCss": [],
    "unusedJs": ["legacyHelper", "tl"]
  },
  "output": {"cssSizeBytes": 3264, "jsSizeBytes": 1735, "originalCssBytes": 564, "originalJsBytes": 353}
}
```

**A note on size**: `output` shows the final file (3264 bytes) is BIGGER than the sum of the sources (564 bytes) — expected on a tiny test project: comment headers have a fixed size per file, and the files here are tiny. On a real project with files a few KB each, the comments' share of the final size will be negligible. If the user is surprised by the size growth, explain it rather than hide it.

## Reading this against WF-3 (the gate)

`.card` and `initApp` have `severity: "high"` — exactly the case where WF-3 requires stopping and asking the user, rather than moving on to `build` silently. `.btn` (medium) and `.container` (low) don't block. `jsOrder` is empty — no ordering contradictions between pages.

## Example final answer to the user (WF-6)

After the user confirmed (or there were no blocking conflicts) and `build` ran:

> Merged 9 internal CSS/JS files (+ 2 vendor) from 3 pages into `style.css` and `scripts.js`.
>
> Conflicts:
> - `.card` — `shared.css` and `shop.css` disagree on `padding` (10px / 20px). Kept both with a note in the comments; by cascade order, `shop.css`'s value (20px) wins since it comes later.
> - `initApp` — a same-named function with a different body in `main.js` and `shop.js`. Also kept both with an explicit warning — worth deciding in the source which version you actually want, the script won't merge them for you.
> - `.btn` and `.container` are defined in more than one file, but without a real conflict — mentioning for completeness, nothing to do here.
>
> The extended analysis found 4 potentially unused CSS classes and 2 JS functions (including `legacyHelper`) — left in the file with a flag, nothing removed.
>
> Don't forget: `analytics.js` (external, on a CDN) wasn't merged in — keep it in `index.html` by hand, or analytics will stop loading.

This is a calibration example for tone and length — not a template to copy verbatim into every answer.
