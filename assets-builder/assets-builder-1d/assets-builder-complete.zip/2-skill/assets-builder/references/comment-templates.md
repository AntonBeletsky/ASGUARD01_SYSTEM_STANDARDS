# Comment header format in `style.css` / `scripts.js`

Below is the script's real output (not a made-up sample), so that when writing a summary for the user the model refers to the actual format.

## Table of contents (top of file)

```css
/* ============================================================
   TABLE OF CONTENTS
   ============================================================
   - assets/css/vendor/tiny-lib.min.css  [vendor] | used on: about.html, index.html, shop.html
   - assets/css/base.css  [shared] | used on: about.html, index.html, shop.html
   - assets/css/pages/shop.css  [page-specific] | used on: shop.html
   - assets/css/unused.css  [orphan]
   ============================================================ */
```
(`--comment-lang ru` gives the same block with a `ОГЛАВЛЕНИЕ` header.)

## Section header (before every source file)

A plain file with no issues:
```css
/* ============================================================
   FILE: assets/css/base.css
   SCOPE: shared
   USED ON: about.html, index.html, shop.html
   SIZE: 92 bytes | 8 lines
   ============================================================ */
```

With a dependency (`@import`) and a conflict:
```css
/* ============================================================
   FILE: assets/css/shared.css
   SCOPE: shared
   USED ON: about.html, index.html, shop.html
   SIZE: 240 bytes | 19 lines
   DEPENDS ON: assets/css/base.css, assets/css/print.css
   CONFLICTS: .btn (severity: medium); .card (severity: high); .container (severity: low)
   ============================================================ */
```

An orphan file (not linked anywhere, but not removed — only flagged):
```css
/* ============================================================
   FILE: assets/css/unused.css
   SCOPE: orphan
   ⚠ ORPHAN — not linked from any scanned HTML page
   SIZE: 32 bytes | 4 lines
   ============================================================ */
```

With an extended-mode note (a class/function wasn't found in use):
```
⚠ POSSIBLY UNUSED (per analysis): .unused-badge (unused)
```
or for the "possibly used dynamically" case (never removed even with `--strip-unused`):
```
⚠ POSSIBLY UNUSED (per analysis): .js-active-state (dynamic-suspect)
```

## `@import` with a media condition

If a file was imported as `@import url("print.css") print;`, its section in the output gets wrapped in `@media` so the original semantics aren't lost:
```css
/* ============================================================
   FILE: assets/css/print.css
   SCOPE: shared
   ...
   ============================================================ */
@media print {
.container { display: none; }
}
```

## Order-conflict banner (`scripts.js` only, only when actually detected)

Placed right after the TOC, before the first section:
```css
/* ############################################################
   WARNING: a contradictory JS include order was detected
   across pages — auto-sorting cannot satisfy both.
   - a.js vs b.js:
       page1.html: a.js -> b.js
       page2.html: b.js -> a.js
   The order below is best-effort (topological + first-seen).
   ############################################################ */
```
If you see this banner in the built file, WF-3 should already have stopped the process before `build` and asked the user; the banner also still appears in `warn` mode if the user knowingly chose to proceed.

## After `--strip-unused`

A removed rule is replaced with a one-line marker, not silently dropped:
```css
/* removed by --strip-unused: .definitely-unused */
```
