# Format of `build-report.json` and `.assets-builder-cache.json`

Both files are real script output (see the full worked report in `references/sample-build-report.md`). Here's what each field means.

## `build-report.json` (read in WF-2/WF-3/WF-6 — the main source for decisions)

```json
{
  "meta": { "generatedAt": "...", "mode": "extended", "totalFiles": 12, "htmlPages": 3, "cssFiles": 6, "jsFiles": 3 },
  "classification": { "shared": [...], "page-specific": [...], "orphan": [...], "vendor": [...] },
  "conflicts": {
    "css": [ { "conflict_type": "css-selector", "name": ".card", "files": [...], "severity": "high", "detail": "..." } ],
    "js":  [ { "conflict_type": "js-symbol", "name": "initApp", "files": [...], "severity": "high", "detail": "..." } ],
    "jsOrder": [ { "files": [...], "page_a": "...", "order_a": [...], "page_b": "...", "order_b": [...] } ]
  },
  "externalAssets": [ { "page": "index.html", "kind": "js-src", "href": "https://...", "line": 6 } ],
  "dominoTop": [ { "file": "assets/css/base.css", "affectedPages": 3 } ],
  "cache": { "reused": 0, "rescanned": 12 },
  "usage": {
    "unusedCss": [".never-linked", "..."],
    "dynamicSuspectCss": [],
    "unusedJs": ["legacyHelper", "..."]
  },
  "output": { "css": "/abs/path/style.css", "js": "/abs/path/scripts.js", "cssSizeBytes": 3297, "jsSizeBytes": 1757, "originalCssBytes": 564, "originalJsBytes": 353 }
}
```

**What to read for WF-3 (the gate)**: `conflicts.css[].severity`, `conflicts.js[].severity`, `conflicts.jsOrder` (an empty array = no problem; non-empty = a blocking situation regardless of `severity`, since `jsOrder` by its nature always needs a human decision).

**`usage` is only present when `--mode extended`** — in `basic` this key doesn't exist at all, it's not an empty object. Check with `"usage" in report`, not `report.get("usage", {})`, if it matters to distinguish "extended, but empty" from "basic".

**`output` is only present for `build`**, not `scan`.

## `.assets-builder-cache.json` (usually no need to read directly — the stats are already in `report["cache"]`)

```json
{
  "cacheVersion": 1,
  "generatedAt": "...",
  "projectRoot": "/abs/path",
  "files": { "assets/css/base.css": { "hash": "...", "size": 92, "mtime": "...", "type": "css" } },
  "parsedCss": { "assets/css/base.css": [ { "selector": ".container", "declarations": {"max-width": "1100px"}, "line": 4 } ] },
  "parsedJs":  { "assets/js/main.js":   [ { "name": "initApp", "line": 1, "body_hash": "a2460a4e" } ] },
  "cssSelectors": { "...": "the same as usage.cssSelectors in the report, if extended" },
  "jsSymbols":    { "...": "same, for JS" },
  "conflicts": [ "a flat list of css+js conflicts, like conflicts.css + conflicts.js in the report" ]
}
```

`parsedCss`/`parsedJs` are what actually speeds up repeat runs: when a file's hash hasn't changed, these entries are reused instead of re-parsing. Deleting an entry from the cache by hand won't break anything — the next `build` will just treat that file as changed and recompute it.

Don't confuse `cssSelectors`/`jsSymbols` in the cache (a flat map keyed by selector/function name, aggregated across the whole project) with `parsedCss`/`parsedJs` (per-file, before aggregation).
