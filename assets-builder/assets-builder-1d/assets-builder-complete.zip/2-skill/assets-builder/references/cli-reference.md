# CLI reference for `assets-builder.py`

Based on the actually implemented and validated code (`scripts/assets-builder.py`), not on the original spec — where the implementation differs from the spec, that's noted explicitly.

## Subcommands

| Command | Purpose | Writes files? |
|---|---|---|
| `scan` | Analysis + report, without writing `style.css`/`scripts.js` | Only the report (if `--report`/`--report-json` is given) |
| `build` | Full pipeline: analysis + build + report + cache (unless `--no-cache`) | Yes |
| `impact <file>` | Domino analysis for one file: which pages a change to it would affect | No |
| `clean-cache` | Delete the cache file | Deletes 1 file |
| `startgui` | Interactive text menu (not a graphical interface) | Same as whatever action is chosen inside it |
| `help [topic]` | Detailed help by topic | No |

## Common flags (all commands except `clean-cache`, `startgui`, `help`)

| Flag | Default | Description |
|---|---|---|
| `--project <path>` | required | Project root |
| `--exclude <a,b,...>` | `""` | Extra exclude patterns (comma-separated, fnmatch syntax). Always ADD to, never replace, `DEFAULT_EXCLUDE = ["dist/**", ".git/**", "node_modules/**"]` |
| `--vendor <a,b,...>` | `""` | Extra explicit vendor patterns. The heuristic (`*.min.css`, `*.min.js`, `vendor/`,`lib/`,`libs/`,`plugins/`,`node_modules/` folders) always applies regardless of this flag |
| `--cache <path>` | `.assets-builder-cache.json` | Cache path, relative to `--project` |
| `--no-cache` | off | Don't read or write the cache |
| `--mode` | `basic` | `basic` \| `extended` (extended — with a usage map, slower) |
| `--quiet` | off | Suppress console output (reports are still written if paths are given) |
| `--verbose` | off | **Currently a no-op** — accepted, but doesn't change behavior |

## `scan`

| Flag | Default | Description |
|---|---|---|
| `--report <path>` | not written | Markdown report, if given |
| `--report-json <path>` | not written | JSON report, if given |

**Exit code**: `0` — no high-severity conflicts found; `1` — at least one CSS or JS conflict with `severity: "high"` was found (this is a signal, not a runtime error).

## `build`

| Flag | Default | Description |
|---|---|---|
| `--out-css <path>` | `dist/style.css` | Relative to `--project` unless absolute |
| `--out-js <path>` | `dist/scripts.js` | Same |
| `--report <path>` | `dist/build-report.md` | |
| `--report-json <path>` | `dist/build-report.json` | |
| `--on-conflict` | `warn` | `warn` (build, flag with comments) \| `fail` (abort before writing files) |
| `--on-order-conflict` | `warn` | Same, but for JS order contradictions between pages |
| `--strip-unused` | off | Only in `extended` mode; removes CSS rules with status `unused`. **Never** touches `dynamic-suspect` — guaranteed at the code level, not just in the docs |
| `--comment-lang` | `en` | `en` \| `ru` — the language of the header labels (`FILE`/`ФАЙЛ` etc.) |

**Exit code**: `0` — success; `2` — `--on-conflict fail` and a high-severity conflict was found (files were NOT written); `3` — `--on-order-conflict fail` and a JS order conflict was found (files were NOT written).

If the output paths (`--out-css`/`--out-js`) are given outside `dist/`, the script still excludes their exact paths from the next analysis run — but it's safer to keep the default.

## `impact <file>`

The positional argument `<file>` is a path **relative to `--project`**, exactly as it appears in reports (`assets/css/base.css`, not absolute and without a leading `/`). Exit code `2` if the file isn't in the project's index.

## `clean-cache`

Only `--project` and `--cache`. Always exits with code `0` (even if there was no cache).

## `startgui`

| Flag | Default | Description |
|---|---|---|
| `--project <path>` | none (optional) | Unlike other commands, not required — can be given inside the menu instead |

Asks the same questions there are flags for `scan`/`build`/`impact`/`clean-cache`, and calls the exact same code — the result is identical to a direct call with the same parameters (validated by a byte-for-byte diff).

## `help [topic]`

`topic` — positional, optional. Topics: `overview`, `scan`, `build`, `impact`, `clean-cache`, `startgui`, `exit-codes`, `defaults`. Complements, doesn't replace, the auto-generated `-h`/`--help`.

## Differences from the original spec (`TZ-assets-builder-script.md` §8)

- `--js-parser heuristic|ast` — only `heuristic` is implemented (it was already the default there too). The `ast` flag doesn't exist in the CLI; don't present it to the user as a working option.
- `--quiet`/`--verbose` exist, but `--verbose` doesn't expand the output.
